<template>
  <Header @toggleSidebar="handleSidebar" @toggle="toggle()" class="d-none"/>
  <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false" class="d-none"/>
  <router-view />
</template>

<script>
import Header from "@/components/Header.vue";
import LeftSidebar from '@/components/LeftSidebar.vue'
export default {
  name: "App",
  components: {
    Header,
    LeftSidebar,
  },
  data() {
    return {
      themeClass: localStorage.getItem("theme-class") || false,
      openSidebar: false,
    };
  },

  methods: {
    handleSidebar() {
      // this.showMenu = !this.showMenu;
      this.openSidebar = true;
    },
    toggle: function () {
      // var PageName = this.$route.name;
      // document.body.classList.add('call-to-doctor-page')
      let appPage = document.body
      let inputBtn = document.querySelector("#checkbox");
      if (inputBtn.checked) {
        appPage.classList.remove("light");
        appPage.classList.add("dark");
        localStorage.setItem("theme-class", "");
        localStorage.setItem("checked", inputBtn.checked);
      } else {
        appPage.classList.add("light");
        appPage.classList.remove("dark");
        localStorage.setItem("theme-class", "light");
        localStorage.setItem("checked", "");
      }
      this.themeClass = localStorage.getItem("theme-class");
    },
  },
  mounted() {
    let appPage = document.body
    this.themeClass = localStorage.getItem("theme-class");
    if (this.themeClass === 'light'){
      appPage.classList.add("light");
      appPage.classList.remove("dark");
    }else {
      appPage.classList.remove("light");
      appPage.classList.add("dark");
    }

    let inputBtn = document.querySelector("#checkbox")
    inputBtn.checked = (localStorage.getItem("checked"))
    console.log(localStorage.getItem("checked"))
    inputBtn.checked = localStorage.getItem("checked") === null;
    if ((localStorage.getItem("theme-class")) === '') {
      inputBtn.checked = true
    }
  }

};
</script>
