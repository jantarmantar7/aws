import { createApp } from 'vue'
import App from './App.vue'
import router from './router' // <---

import vuecookies from 'vue-cookies'
import VueSweetalert2 from 'vue-sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css';

import "bootstrap/dist/js/bootstrap.js"
import 'bootstrap/dist/css/bootstrap.css'
import './assets/scss/main.scss'


let app = createApp(App)
app.use(router)
.use(vuecookies, { expires: '7d'})
.use(VueSweetalert2)
.mount('#app')

app.config.globalProperties.$api = 'https://beta.traderboard.app/app'