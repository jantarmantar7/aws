import { createWebHistory, createRouter } from "vue-router";
import Home from "@/views/HomeView.vue";
import Login from "@/views/LoginView.vue";
import Register from "@/views/RegisterView.vue";
import Subscribe from "@/views/SubscribeView.vue";
import Settings from "@/views/SettingsView.vue";
import Leaderboard from "@/views/LeaderboardView.vue";
import Mytrades from "@/views/MytradesView.vue";
import Referral from "@/views/ReferralView.vue";
import Help from "@/views/HelpView.vue";
import OpenTicketView from "@/views/OpenTicketView.vue";
import Trader from "@/views/TraderView.vue";

const routes = [
    {
        path: "/",
        name: "Home",
        component: Home,
        meta: {
            title: "Traderboard - Dashboard",
        },
    },
    {
        path: "/login",
        name: "Login",
        component: Login,
        meta: {
            title: "Traderboard - Login",
        },
    },
    {
        path: "/register",
        name: "Register",
        component: Register,
        meta: {
            title: "Traderboard - Sign up",
        },
    },
    {
        path: "/signup",
        name: "Sign up",
        component: Register,
        meta: {
            title: "Traderboard - Sign up",
        },
    },
    {
        path: "/subscribe",
        name: "Subscribe",
        component: Subscribe,
        meta: {
            title: "Traderboard - Subscribe",
        },
    },
    {
        path: "/settings",
        name: "Settings",
        component: Settings,
        meta: {
            title: "Traderboard - Settings",
        },
    },
    {
        path: "/leaderboard",
        name: "Leaderboard",
        component: Leaderboard,
        meta: {
            title: "Traderboard - Leaderboard",
        },
    },
    {
        path: "/mytrades",
        name: "My trades",
        component: Mytrades,
        meta: {
            title: "Traderboard - My trades",
        },
    },
    {
        path: "/referral",
        name: "Referral",
        component: Referral,
        meta: {
            title: "Traderboard - Referral",
        },
    },
    {
        path: "/help",
        name: "Help",
        component: Help,
        meta: {
            title: "Traderboard - Help",
        },
    },
    {
        path: "/new-ticket",
        name: "OpenTicketView",
        component: OpenTicketView,
        meta: {
            title: "Traderboard - Open Ticket",
        },
    },
    {
        path: "/trader/:slug",
        name: "Trader",
        component: Trader,
        meta: {
            title: "Traderboard - Trader",
        },
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

router.beforeEach((to, from, next) => {
    document.title = to.meta.title ? to.meta.title : "Traderboard"
    next() 
})

export default router;
