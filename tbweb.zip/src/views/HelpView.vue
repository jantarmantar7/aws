<template>
    <div class="help">
      <Header @toggleSidebar="handleSidebar"/>
      <div class="admin-dashboard">
        <section id="main-content" class="admin-dashboard">
          <div class="container">
            <div class="row">
              <div class="col-xl-2 col-md-12">
                <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false"/>
              </div>
              <div class="col-xl-10 col-md-12" v-if="!openTicket">
                <div class="main-content-body">
                    <div class="manage-trade-wrapper">

                      <div class="ticket-title">
                        <h3>Your tickets</h3> <router-link to="/new-ticket"><button class="btn button">New ticket</button></router-link>
                      </div>

                      <div class="manage-trade-table table-responsive">
                        <table class="table m-b-0 table-hover" border="0">
                          <thead>
                          <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Status</th>
                          </tr>
                          </thead>
                          <tbody v-for="ticket in tickets" :key="ticket.id" >
                            <tr @click="viewTicket(ticket.id)">
                                <td>{{ ticket.id }}</td>
                                <td>{{ ticket.subject }}</td>
                                <td>{{ ticket.date }}</td>
                                <td>
                                  <span v-if="ticket.status == 'open'" class="tag green">Open</span>
                                  <span v-else class="tag red">Close</span>
                                </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
              </div>
              <div class="col-xl-10 col-md-12" v-else>
                <div class="main-content-body">
                    <div class="manage-trade-wrapper general-form ticket">
                        <button @click="openTicket = false" class="btn button back">Go back</button>
                        <div class="box" v-for="item in messages" :key="item.id">
                            <p class="sender">{{ item.user }}</p>
                            <p class="date">{{ item.date }}</p>
                            <p class="message">{{ item.msg }}</p>
                        </div>

                        <div class="box addreply">
                            <form @submit.prevent="addReply">
                                <label>Add reply</label>
                                <textarea v-model="newmessage" class="form-control" name="reply" id="reply" max="300" placeholder="Remember to add some useful details to the case."></textarea>
                                <button v-on:click="addReply()" class="btn button">Submit</button>
                            </form>
                        </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </template>
  
  
  <script>
  // @ is an alias to /src
  import Header from "@/components/Header.vue";
  import LeftSidebar from '@/components/LeftSidebar.vue'
  import axios from 'axios'
  export default {
    name: 'HelpView',
    components: {
      Header,
      LeftSidebar,
    },
    data() {
      return {
        openSidebar: false,
        openTicket: false,
        tid: 0,

        subject: '',
        message: '',

        tickets: [],
        messages: [],
      }
    },
    mounted(){
      this.listTickets()
      this.isLogged()
    },
    methods:{
      handleSidebar() {
        // this.showMenu = !this.showMenu;
        this.openSidebar = true;
      },
      listTickets() {
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/listTickets',
        { 
          token: token,
        },)
        .then((response) => {
          this.tickets = response.data;
        });
      },
      isLogged() {
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/isLogged',
          { 
            token: token
          },
        )
        .then((response) => {
          if(response.data == 1) {
            this.$router.push({ path: '/login' })
          } 
        });
      },
      viewTicket(id) {
        this.tid = id;
        this.openTicket = true;
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/viewTicket',
          { 
            token: token,
            id: id,
          },
        )
        .then((response) => {
          console.log(response.data)
          this.messages = response.data
        });
      },
      addReply() {
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/newReply',
          { 
            token: token,
            message: this.newmessage,
            tid: this.tid
          },
        )
        .then((response) => {
          console.log(response.data)
          if(response.data == 0) {
            this.$swal({
                title: 'Success',
                text: "We have received your message and will get back to you soon.",
                type: 'success',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ok'
            })

            this.viewTicket(this.tid);
          } else {
                this.$swal({
                    title: 'Unable to send',
                    text: "Could not send your message, please rety.",
                    type: 'error',
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ok'
                })
          }
        });
      }
    }
  }
  </script>
  
  <style lang="scss" scoped>
  
  </style>
  