<template>
    <div class="pricing">
      <Header @toggleSidebar="handleSidebar"/>
      <div class="admin-dashboard">
        <section id="main-content" class="admin-dashboard">
          <div class="container">
            <div class="row">
              <div class="col-xl-2 col-md-12">
                <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false"/>
              </div>
              <div class="col-xl-10 col-md-12">
                <div class="main-content-body">
                  <div class="manage-trade-wrapper">
                    <h3>Subscribe</h3>
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="pricing-table">
                                <div class="title">
                                  <h4>Autopilot</h4>
                                  <select @change="AP_plan()" v-model="AP_time">
                                    <option value="1">1 Month</option>
                                    <option value="6">6 Month</option>
                                    <option value="12">12 Months</option>
                                  </select>
                                </div>
                                <h2 class="price">${{ AP_price }}/{{ AP_period }} <span v-if="AP_discounted">Save {{ AP_discount }}</span></h2>

                                <p>We select the best traders and copy them into your account, with matching leverage.</p>
                                <ul>
                                    <li>Matching leverage</li>
                                    <li>Preset of traders</li>
                                    <li>Leaderboard Copytrade</li>
                                    <li>Auto DCA & Resizing</li>
                                </ul>

                                <button id="AP_Crypto" @click="goPay('AP', 'crypto')" class="btn button"><i class="fa-solid fa-bitcoin-sign"></i> Pay with Crypto</button>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <div class="pricing-table">
                                <div class="title">
                                  <h4>Premium</h4>
                                  <select @change="PP_plan()" v-model="PP_time">
                                    <option value="1">1 Month</option>
                                    <option value="6">6 Month</option>
                                    <option value="12">12 Months</option>
                                  </select>
                                </div>
                                <h2 class="price">${{ PP_price }}/{{ PP_period }} <span v-if="PP_discounted">Save {{ PP_discount }}</span></h2>

                                <p>Allow you to customize everything and choose who to copy, up to 20x leverage.</p>
                                <ul>
                                    <li>Up to 50x leverage</li>
                                    <li>Choose who to follow</li>
                                    <li>Leaderboard Copytrade</li>
                                    <li>Auto DCA & Resizing</li>
                                </ul>

                                <button id="PP_Card" @click="goPay('PP', 'card')" class="btn button"><i class="fa-solid fa-credit-card"></i> Pay with Card</button>
                                <button id="PP_Crypto" @click="goPay('PP', 'crypto')" class="btn button"><i class="fa-solid fa-bitcoin-sign"></i> Pay with Crypto</button>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </template>
  
  
  <script>
  // @ is an alias to /src
  import Header from "@/components/Header.vue";
  import LeftSidebar from '@/components/LeftSidebar.vue'
  import axios from 'axios'
  export default {
    name: 'SubscribeView',
    components: {
      Header,
      LeftSidebar,
    },
    data() {
      return {
        openSidebar: false,
        AP_price: 69,
        AP_period: 'month',
        AP_time: 1,

        PP_price: 99,
        PP_period: 'month',
        PP_time: 1,

        AP_discounted: false,
        AP_discount: 0,
        PP_discounted: false,
        PP_discount: 0,

        AP_chosenplan: 4,
        PP_chosenplan: 1,
      }
    },
    mounted(){
      
    },
    methods:{
      handleSidebar() {
        // this.showMenu = !this.showMenu;
        this.openSidebar = true;
      },
      isLogged() {
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/isLogged',
          { 
            token: token
          },
        )
        .then((response) => {
          if(response.data == 1) {
            this.$router.push({ path: 'login' })
          } 
        });
      },
      AP_plan() {
        document.getElementById("AP_Crypto").disabled = true;
        setTimeout(function(){document.getElementById("AP_Crypto").disabled = false;},1500);

        var id = this.AP_time;
        if(id == 1){
          this.AP_price = 69;
          this.AP_period = 'month';
          this.AP_chosenplan = 4;
          this.AP_discounted = false;
          this.AP_discount = '$0'
        }
        else if(id == 6) {
          this.AP_price = 87;
          this.AP_period = 'six months';
          this.AP_chosenplan = 5;
          this.AP_discounted = true;
          this.AP_discount = '$35'
        }
        else if(id == 12) {
          this.AP_price = 666;
          this.AP_period = 'Annually';
          this.AP_chosenplan = 6;
          this.AP_discounted = true;
          this.AP_discount = '$174'
        }
      },
      PP_plan() {
        var id = this.PP_time;
        document.getElementById("PP_Card").disabled = true;
        setTimeout(function(){document.getElementById("PP_Card").disabled = false;},1500);

        document.getElementById("PP_Crypto").disabled = true;
        setTimeout(function(){document.getElementById("PP_Crypto").disabled = false;},1500);
        
        if(id == 1){
          this.PP_price = 99;
          this.PP_period = 'month';
          this.PP_chosenplan = 1;
          this.PP_discounted = false;
          this.PP_discount = '$0'
        }
        else if(id == 6) {
          this.PP_price = 444;
          this.PP_period = 'six months';
          this.PP_chosenplan = 2;
          this.PP_discounted = true;
          this.PP_discount = '$156'
        }
        else if(id == 12) {
          this.PP_price = 888;
          this.PP_period = 'Annually';
          this.PP_chosenplan = 3;
          this.PP_discounted = true;
          this.PP_discount = '$312'
        }
      },
      goPay(type, method) {
        var token =  localStorage.getItem("session"); 
        var id = 0;
        if(type == 'AP')
          id = this.AP_chosenplan;
        else if(type == 'PP')
          id = this.PP_chosenplan;

        axios.post(this.$api+'/pay',
          { 
            token: token,
            id: id,
            method: method,
          },
        )
        .then((response) => {
          console.log(response.data)
          var link = response.data;
          link = link.trim();
          window.location.href = link;
        });
      },
    },
    beforeMount() {
      this.isLogged()
    }
  }
  </script>
  
  <style lang="scss" scoped>
  
  </style>
  