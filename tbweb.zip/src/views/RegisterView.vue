<template>
    <div class="login">
        <Header @toggleSidebar="handleSidebar"/>
        <div class="admin-dashboard">
            <section id="main-content" class="admin-dashboard">
              <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-sm-5 px-0">
                        <div class="leftlogin">
                        </div>
                        <center>
                            <img class="logo" src="@/assets/images/logo.png" />
                        </center>
                    </div>
                    <div class="col-sm-6">
                        <div class="rightlogin">
                            <div class="auth-form">
                                <h2>Create your account</h2>
                                <form method="POST" action="" @submit.prevent="register">
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Username</label>
                                        <input v-model="username" type="text" class="form-control" id="exampleInputPassword1" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input v-model="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Password</label>
                                        <input v-model="pass" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Confirm password</label>
                                        <input v-model="verifypass" type="password" class="form-control" id="exampleInputPassword1" placeholder="Confirm password">
                                    </div>

                                    <div class="form-group">
                                        <vue-hcaptcha @verify="onVerify" @error="onError" sitekey="e661ab2a-1877-474b-bd93-edb1d9a4f363"></vue-hcaptcha>
                                    </div>

                                    <button v-on:click="register" type="submit" class="btn btn-primary">Register</button>
                                    <p>Already have an account? <router-link to="/login">Login.</router-link></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
            </section>
        </div>
    </div>
</template>

<script>
// @ is an alias to /src
import VueHcaptcha from '@hcaptcha/vue3-hcaptcha';
import axios from 'axios'
export default {
  name: 'HomeView',
  components: {
    VueHcaptcha,
  },
  data() {
    return {
        captchaSolved: false,

        username: '',
        email: '',
        pass: '',
        verifypass: '',
    }
  },
  mounted(){
    this.isCopyLeaders()
  },
  methods:{
    handleSidebar() {
      // this.showMenu = !this.showMenu;
    },
    isCopyLeaders() {
      if(window.location.hostname == 'web.copyleaders.co') {
        document.title = 'CopyLeaders';
        return true
      }
      else
        return false
    },
    register() {
        var token =  localStorage.getItem("session"); 
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const ref = urlParams.get('ref')
        const id = urlParams.get('id')
        var referral = 0;
        if(isNaN(ref)) {
            referral = ref;
        }
        
        axios.post(this.$api+'/doRegister',
          { 
            token: token,
            username: this.username,
            email: this.email,
            pass: this.pass,
            verifypass: this.verifypass,
            ref: referral,
          },
        )
        .then((response) => {
            localStorage.setItem("ref", ref);
            if(response.data == 0) {
                this.$swal({
                    title: 'Success',
                    text: "You've registered to our platform, login to continue.",
                    type: 'success',
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ok'
                })

                if(id != null) {
                    setTimeout(this.$router.push('/login?subscribe=1') , 1500);
                }
            } else {
                this.$swal({
                    title: 'Error',
                    text: "Unable to register your account.",
                    type: 'error',
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ok'
                })
            }
        });
    },
    onVerify() {
        this.captchaSolved = true
    },
    onError() {
        this.captchaSolved = false
    }
  }
}
</script>

<style lang="scss" scoped>

</style>