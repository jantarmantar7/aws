<template>
    <div class="login">
        <Header @toggleSidebar="handleSidebar"/>
        <div class="admin-dashboard">
            <section id="main-content" class="admin-dashboard">
              <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-sm-5 px-0">
                        <div class="leftlogin">
                        </div>
                        <center>
                            <img class="logo" src="@/assets/images/logo.png" />
                        </center>
                    </div>
                    <div class="col-sm-6">
                        <div class="rightlogin">
                            <div class="auth-form">
                                <h2>Sign into your account</h2>
                                <form method="POST" action="" @submit.prevent="login" >
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Email address</label>
                                        <input v-model="email" type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                                    <small id="email" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input v-model="password" type="password" class="form-control" name="password" id="password" placeholder="Password">
                                    </div>

                                    <button type="submit" v-on:click="login()" class="btn btn-primary">Login</button>
                                    <p>Don't have an account yet? <router-link to="/register">Sign up today.</router-link></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
            </section>
        </div>
    </div>
</template>

<script>
import axios from 'axios'

// @ is an alias to /src
export default {
  name: 'HomeView',
  components: {
  },
  data() {
    return {
      email: '',
      password: '',
    }
  },
  mounted(){
    this.isCopyLeaders()
  },
  methods:{
    handleSidebar() {
      // this.showMenu = !this.showMenu;
    },
    isCopyLeaders() {
      if(window.location.hostname == 'web.copyleaders.co') {
        document.title = 'CopyLeaders';
        return true
      }
      else
        return false
    },
    login () {
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      const sub = urlParams.get('subscribe')

      axios.post(this.$api+'/doLogin',
        { 
          email: this.email,
          password: this.password
        },
      )
      .then((response) => {
        if(response.data != 1) {
          var token = response.data
          token = token.trim()
          localStorage.setItem("session", token);

          if(sub != null) {
            this.$router.push('/subscribe');
          } else {
            this.$router.push('/');
          }
        } else {
            this.$swal({
              title: 'Couldn\'t login',
              text: "Your email and password do not match our records.",
              type: 'error',
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok'
            })
        }
      });
    },
  }
}
</script>

<style lang="scss" scoped>

</style>