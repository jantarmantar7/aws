<template>
    <div class="referral">
      <Header @toggleSidebar="handleSidebar"/>
      <div class="admin-dashboard">
        <section id="main-content" class="admin-dashboard">
          <div class="container">
            <div class="row">
              <div class="col-xl-2 col-md-12">
                <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false"/>
              </div>
              <div class="col-xl-10 col-md-12">
                <div class="main-content-body">
                  <div class="manage-trade-wrapper">
                    <h3>Referral</h3>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="box">
                                <form>
                                    <label>Sign up link</label>
                                    <input type="text" class="form-control" :value="'https://web.traderboard.app/register?ref='+refID" readonly>

                                    <label>Home link</label>
                                    <input type="text" class="form-control" :value="'https://traderboard.app/?ref='+refID" readonly>
                                </form>
                            </div>
                        </div>
                        <div class="col-sm-8 analytics">
                            <div class="row mt-5">
                                <div class="col-sm-4">
                                    <h4>Signups</h4>
                                    <h4>{{ signups }}</h4>
                                </div>
                                <div class="col-sm-4">
                                    <h4>Active subs</h4>
                                    <h4>{{ paidsignups }}</h4>
                                </div>
                                <div class="col-sm-4">
                                    <h4>Earnings</h4>
                                    <h4>${{ earnings }}</h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-5">
                        <div class="manage-trade-table table-responsive">
                            <table class="table m-b-0 table-hover" border="0">
                              <thead>
                              <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Subscription</th>
                              </tr>
                              </thead>
                              <tbody>
                                  <tr v-for="user in referredList" :key="user.id">
                                      <td>{{ user.id }}</td>
                                      <td>{{ user.username}}</td>
                                      <td>{{ user.email }}</td>
                                      <td>{{ user.membership }}</td>
                                  </tr>
                              </tbody>
                            </table>
                          </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </template>
  
  
  <script>
  // @ is an alias to /src
  import Header from "@/components/Header.vue";
  import LeftSidebar from '@/components/LeftSidebar.vue'
  import axios from 'axios'
  export default {
    name: 'ReferralView',
    components: {
      Header,
      LeftSidebar,
    },
    data() {
      return {
        openSidebar: false,
        referredList: [],
        refID: 0,
        signups: 0,
        paidsignups: 0,
        earnings: 0.00,
      }
    },
    mounted(){
      this.getRefList()
      this.isLogged()
      this.getRefID()
    },
    methods:{
      handleSidebar() {
        // this.showMenu = !this.showMenu;
        this.openSidebar = true;
      },
      isLogged() {
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/isLogged',
          { 
            token: token
          },
        )
        .then((response) => {
          if(response.data == 1) {
            this.$router.push({ path: 'login' })
          } 
        });
      },
      getRefID() {
        var token =  localStorage.getItem("session");
        axios.post(this.$api+'/getRefID',
          { 
            token: token,
          },
        )
        .then((response) => {
          this.refID = response.data
          console.log(response.data)
        });
      },
      getRefList() {
        var token =  localStorage.getItem("session");
        axios.post(this.$api+'/getRefSignups',
          { 
            token: token,
          },
        )
        .then((response) => {
          this.referredList = response.data
          this.signups = response.data[0]['signups']
          this.paidsignups = response.data[0]['paidsignups']
          this.earnings = response.data[0]['earnings']
        });
      }
    }
  }
  </script>
  
  <style lang="scss" scoped>
  
  </style>
  