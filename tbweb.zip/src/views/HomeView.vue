<template>
  <div class="home">
    <Header @toggleSidebar="handleSidebar"/>
    <div class="admin-dashboard">
      <section id="main-content" class="admin-dashboard">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-md-12">
              <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false"/>
            </div>
            <div class="col-xl-10 col-md-12">
              <div class="main-content-body">
                <div class="manage-trade-wrapper">
                  <h3>Ongoing trades</h3>
                  <div class="manage-trade-table table-responsive">
                    <table class="table m-b-0 table-hover" border="0">
                      <thead>
                      <tr>
                        <th>Trader</th>
                        <th>Symbol</th>
                        <th>Type</th>
                        <th>Entry</th>
                        <th>Unrealized profit</th>
                      </tr>
                      </thead>
                      <p class="warning-text" v-if="nopositions">No position detected on our traders.</p>
                      <tbody v-for="pos in positions" :key="pos.id">
                      <tr>
                        <td><img src="../assets/images/icons/user-icon.png" alt="icon"> {{ pos.trader }}</td>
                        <td>
                          <ul class="coins">
                            <li><img :src="'https://web.traderboard.app/coins/'+pos.pair.toLowerCase()+'.png'" alt="icon"></li>
                            <li><img src="../assets/images/icons/usdt-icon.png" alt="icon"></li>
                          </ul>
                          {{ pos.pair }}
                        </td>
                        <td>
                          <span v-if="pos.type.includes('Long')" class="tag green">Long</span>
                          <span v-else class="tag red">Short</span>
                        </td>
                        <td>${{ pos.entry }}</td>
                        <td>
                          <span :class="pos.color">{{ pos.pnl }}</span>
                        </td>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>


<script>
// @ is an alias to /src
import Header from "@/components/Header.vue";
import LeftSidebar from '@/components/LeftSidebar.vue'
import axios from 'axios'

export default {
  name: 'HomeView',
  components: {
    Header,
    LeftSidebar,
  },
  data() {
    return {
      openSidebar: false,
      positions: [],
      nopositions: false,
    }
  },
  mounted(){

  },
  methods:{
    handleSidebar() {
      // this.showMenu = !this.showMenu;
      this.openSidebar = true;
    },
    isLogged() {
      var token =  localStorage.getItem("session"); 
      axios.post(this.$api+'/isLogged',
        { 
          token: token
        },
      )
      .then((response) => {
        if(response.data == 1) {
          this.$router.push({ path: 'login' })
        } 
      });
    },
    getOngoingTrades() {
      axios.get(this.$api+'/listLeaderPositions.php?do=allpos')
      .then((response) => {
        var data = response.data;
        this.positions = data;
        if(data.length == 0) {
          this.nopositions = true
        }
      });
    }
  },
  beforeMount() {
    this.isLogged()
    this.getOngoingTrades()
  }
}
</script>

<style lang="scss" scoped>

</style>
