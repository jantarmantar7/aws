<template>
  <div class="leaderboard">
    <Header @toggleSidebar="handleSidebar"/>
    <div class="admin-dashboard">
      <section id="main-content" class="admin-dashboard">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-md-12">
              <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false"/>
            </div>
            <div class="col-xl-10 col-md-12">
              <div class="main-content-body">
                <div class="manage-trade-wrapper general-form">
                  <h3>Leaderboard</h3>

                  <div class="row">
                      <div class="col-sm-4" v-for="trader in leaderboard" :key="trader.id">
                          <div class="box">
                              <div class="row">
                                  <div class="col-8">
                                      <h4>{{ trader.trader }} <a target="_blank" :href="trader.link"><img class="link" src="@/assets/images/link.svg" /></a> </h4>
                                  </div>
                                  <div class="col-4">
                                      <span v-if="trader.recommended == 'yes'" class="badge badge-warning badge-recommended">RECOMMENDED</span>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="col-6">
                                      <ul>
                                          <li>Total ROI: <span>{{trader.all_roi}}</span></li>
                                          <li>Active trades: <b>{{ trader.activetrades }}</b></li>
                                          <li><b>{{trader.followers}}</b> followers</li>
                                      </ul>
                                  </div>
                                  <div class="col-6">
                                      <ul>
                                          <li>Monthly ROI: <span>{{trader.monthly_roi}}</span></li>
                                          <li>Weekly ROI: <span>{{trader.weekly_roi}}</span></li>
                                      </ul>
                                  </div>
                              </div>

                              <div class="row mt-2">
                                  <div class="col-sm-6">
                                      <button v-if="trader.following == 'yes'" @click="stopCopyingTrader()" class="btn button-red">Stop Copying</button>
                                      <button v-else @click="copyTrader(trader.trader);" class="btn button">Copy</button>
                                  </div>
                                  <div class="col-sm-6">
                                      <router-link :to="'/trader/'+trader.trader"><button class="btn button-secondary">View profile</button></router-link>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                    
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>
  
  
<script>
// @ is an alias to /src
import Header from "@/components/Header.vue";
import LeftSidebar from '@/components/LeftSidebar.vue'
import axios from 'axios'

export default {
  name: 'LeaderboardView',
  components: {
    Header,
    LeftSidebar,
  },
  data() {
    return {
      openSidebar: false,
      leaderboard: [],
    }
  },
  mounted(){

  },
  methods:{
    handleSidebar() {
      // this.showMenu = !this.showMenu;
      this.openSidebar = true;
    },
    isLogged() {
      var token =  localStorage.getItem("session"); 
      axios.post(this.$api+'/isLogged',
        { 
          token: token
        },
      )
      .then((response) => {
        if(response.data == 1) {
          this.$router.push({ path: 'login' })
        } 
      });
    },
    getLeaderboard() {
      var token =  localStorage.getItem("session"); 
      axios.post(this.$api+'/getLeaderboard.php', {
        token: token,
      })
      .then((response) => {
        console.log(response.data)
        this.leaderboard = response.data
      });
    },
    copyTrader(name) {
      var token =  localStorage.getItem("session"); 
      var tname = name;
      axios.post(this.$api+'/followTrader',
        { 
          token: token,
          trader: tname,
        },
      )
      .then((response) => {
        if(response.data == 0) {
            this.$swal({
              title: 'Success',
              text: "You're now copying him.",
              type: 'success',
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok'
            })
            this.getLeaderboard()
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            this.$swal({
              title: 'Error',
              text: "Premium subscription is required to start copytrading.",
              type: 'error',
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok'
            })
        }
      });
    },
    stopCopyingTrader() {
      var token =  localStorage.getItem("session"); 
      axios.post(this.$api+'/unfollowTrader',
        { 
          token: token
        },
      )
      .then((response) => {
        if(response.data == 0) {
            this.$swal({
              title: 'Success',
              text: "You've stopped copying the trader.",
              type: 'success',
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok'
            })
            this.getLeaderboard()
        }  else {
            this.$swal({
              title: 'Error',
              text: "Your plan does not allow you to choose traders.",
              type: 'error',
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok'
            })
        }
      });
    }
  },
  beforeMount() {
    this.getLeaderboard()
  }
}
</script>

<style lang="scss" scoped>

</style>
