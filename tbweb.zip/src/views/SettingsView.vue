<template>
  <div class="settings">
    <Header @toggleSidebar="handleSidebar"/>
    <div class="admin-dashboard">
      <section id="main-content" class="admin-dashboard">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-md-12">
              <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false"/>
            </div>
            <div class="col-xl-10 col-md-12">
              <div class="main-content-body">
                <div class="manage-trade-wrapper general-form">
                  <h3>Settings</h3>

                  <form @submit.prevent="updateSettings">
                      <div class="row mb-4">
                        <div class="col-sm-6">
                          <label>API Public Key</label>
                          <input v-model="apikey" type="text" class="form-control" placeholder="Enter your exchange API's generated public key.">
                        </div>
                        <div class="col-sm-6">
                          <label>API Secret Key</label>
                          <input v-model="secret" type="text" class="form-control" placeholder="If this is empty, we'll keep your old key.">
                        </div>
                      </div>
                      <div class="row mb-4">
                          <div class="col-sm-6">
                              <div class="form-check form-switch">
                                  <input v-on:change="toggleSizing" v-model="ratioSizing" :checked="ratioSizing" class="form-check-input" type="checkbox" id="ratiosizing">
                                  <label class="form-check-label" for="ratiosizing">Ratio sizing</label>
                              </div>
                          </div>
                      </div>
                      <div class="row mb-4">
                          <div class="col-sm-12">
                              <label>Amount per trades</label>
                              <div class="input-group">
                                  <span class="input-group-text" id="amount">{{ mode }}</span>
                                  <input v-if="amountSizing" type="text" v-model="amount" class="form-control" :placeholder="amtplaceholder" aria-label="amount" aria-describedby="amount">
                                  <input v-else type="text" v-model="ratio" class="form-control" :placeholder="ratioplaceholder" aria-label="ratio" aria-describedby="ratio">
                              </div>
                              <small v-if="!amountSizing">* your orders will use a percentage of trader size, make sure to have enough funds.</small>
                          </div>
                      </div>
                      <div class="row mb-4">
                          <div class="col-sm-3">
                              <label>Leverage</label>
                              <div class="form-check form-switch">
                                  <input v-on:change="toggleSizing" v-model="autoLeverage" :checked="autoLeverage" class="form-check-input" type="checkbox" id="ratiosizing">
                                  <label class="form-check-label" for="ratiosizing">Use same leverage as trader</label>
                              </div>
                              <div v-if="!autoLeverage" class="input-group">
                                  <input v-model="customLeverage"  type="number" class="form-control" min="1" max="50" step="1" id="leverage">
                              </div>
                          </div>
                      </div>
                      <div class="row mb-4">
                          <div class="col-sm-12">
                              <label>Which platform are you using?</label>
                              <div class="input-group">
                                  <div class="form-check form-check-inline">
                                      <input :checked="exchange == 'binance'" v-model="exchange" class="form-check-input" type="radio" value="binance" name="inlineRadioOptions" id="inlineRadio1">
                                      <label class="form-check-label" for="inlineRadio1">Binance</label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                      <input :checked="exchange == 'bybit'" v-model="exchange" class="form-check-input" type="radio" value="bybit" name="inlineRadioOptions" id="inlineRadio2">
                                      <label class="form-check-label" for="inlineRadio2">Bybit</label>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="row mb-4">
                          <div class="col-sm-12">
                              <label>IP to whitelist</label>
                              <ul>
                                <li>159.69.37.51</li>
                                <li>156.238.7.95</li>
                                <li>45.153.22.100</li>
                                <li>104.233.19.57</li>
                                <li>45.152.208.107</li>
                                <li>91.246.192.207</li>
                                <li>104.143.246.129</li>
                                <li>45.153.22.198</li>
                                <li>104.233.19.15</li>
                                <li>194.39.33.80</li>
                                <li>194.39.33.219</li>
                              </ul>
                          </div>
                      </div>

                      <div class="row mb-4">
                          <div class="col-sm-12">
                              <button v-on:click="updateSettings" class="btn button">Save</button>
                          </div>
                      </div>
                  </form>
                    
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>


<script>
// @ is an alias to /src
import Header from "@/components/Header.vue";
import LeftSidebar from '@/components/LeftSidebar.vue'
import axios from 'axios'

export default {
  name: 'SettingsView',
  components: {
    Header,
    LeftSidebar,
  },
  data() {
    return {
      openSidebar: false,
      ratioSizing: false,
      amountSizing: true,
      mode: 'USDT',
      amtplaceholder: '500',
      ratioplaceholder: '100',

      apikey: '',
      secret: '',
      amount: 0,
      ratio: 0,
      exchange: 'binance',

      autoLeverage: false,
      customLeverage: 1,
      
    }
  },
  mounted(){

  },
  methods:{
    handleSidebar() {
      // this.showMenu = !this.showMenu;
      this.openSidebar = true;
    },
    toggleSizing() {
      if(this.ratioSizing) {
        this.ratioSizing = true
        this.amountSizing = false
        this.mode = '%'
        this.amount = 0
      } else {
        this.ratioSizing = false
        this.amountSizing = true
        this.mode = 'USDT'
        this.ratio = 0
      }
    },
    isLogged() {
      var token =  localStorage.getItem("session"); 
      axios.post(this.$api+'/isLogged',
        { 
          token: token
        },
      )
      .then((response) => {
        if(response.data == 1) {
          this.$router.push({ path: 'login' })
        } 
      });
    },
    getSettings() {
      var token =  localStorage.getItem("session"); 
      axios.post(this.$api+'/getSettings',
        { 
          token: token
        },
      )
      .then((response) => {
        this.apikey = response.data.apikey;
        this.amount = response.data.amount;
        this.ratio = response.data.percentage;
        this.exchange = response.data.exchange;

        if(response.data.leverage == 0)
          this.autoLeverage = true
        else
          this.leverage = response.data.leverage

        if(this.ratio != 0) {
          this.ratioSizing = true
          this.amountSizing = false
          this.mode = '%'
          this.amount = 0
        }
      });
    },
    updateSettings() {
      var leverage = 1
      if(!this.autoLeverage)
        leverage = this.customLeverage
      else
        leverage = 0

      var token =  localStorage.getItem("session"); 
      axios.post(this.$api+'/updateSettings',
        { 
          token: token,
          apikey: this.apikey,
          secret: this.secret,
          ratio: this.ratio,
          exchange: this.exchange,
          amount: this.amount,
          leverage: leverage,
        },
      )
      .then((response) => {
        console.log(response.data)
        this.getSettings()
        if(response.data == 0) {
          this.$swal({
              title: 'Success',
              text: "Your account settings have been updated.",
              type: 'success',
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok'
            })
        } else {
            this.$swal({
              title: 'Error',
              text: "Verify your account email before updating settings.",
              type: 'error',
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Ok'
            })
        }
      });
    }
  },
  beforeMount() {
    this.isLogged()
    this.getSettings()
  }
}
</script>

<style lang="scss" scoped>

</style>
