<template>
    <div class="help">
      <Header @toggleSidebar="handleSidebar"/>
      <div class="admin-dashboard">
        <section id="main-content" class="admin-dashboard">
          <div class="container">
            <div class="row">
              <div class="col-xl-2 col-md-12">
                <LeftSidebar :class="{ 'active' : openSidebar }" @closeSidebar="openSidebar = false"/>
              </div>
              <div class="col-xl-10 col-md-12" v-if="!openTicket">
                <div class="main-content-body">
                    <div class="manage-trade-wrapper">

                      <div class="ticket-title">
                        <h3>Open a ticket</h3>
                      </div>

                        <div class="manage-trade-wrapper general-form">
                            <form @submit.prevent="newTicket">
                                <label>Subject</label>
                                <input v-model="subject" class="form-control" id="subject" name="subject" placeholder="I have a problem.." required>
                                
                                <br/>

                                <label>Message</label>
                                <textarea v-model="message" class="form-control" id="message" name="message" max="300" placeholder="Remember to add some useful details to the case." required></textarea>
                                
                                <br/>

                                <button class="btn button" v-on:click="newTicket()">Open</button>
                            </form>
                        </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </template>
  
  
  <script>
  // @ is an alias to /src
  import Header from "@/components/Header.vue";
  import LeftSidebar from '@/components/LeftSidebar.vue'
  import axios from 'axios'
  export default {
    name: 'OpenTicketView',
    components: {
      Header,
      LeftSidebar,
    },
    data() {
      return {
        openSidebar: false,
        subject: '',
        message: '',
      }
    },
    mounted(){
        this.isLogged()
    },
    methods:{
      handleSidebar() {
        // this.showMenu = !this.showMenu;
        this.openSidebar = true;
      },
      newTicket() {
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/newTicket.php',
          { 
            token: token,
            subject: this.subject,
            message: this.message,
          },
        )
        .then((response) => {
            console.log(response.data)
            if(response.data == 1) {
                this.$router.push('/help');
            } 
            else if(response.data == 0) {
                this.$swal({
                    title: 'Couldn\'t open',
                    text: "You can only open one ticket at time.",
                    type: 'error',
                    showCancelButton: false,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ok'
                })
            }
        });
      },
      isLogged() {
        var token =  localStorage.getItem("session"); 
        axios.post(this.$api+'/isLogged',
          { 
            token: token
          },
        )
        .then((response) => {
          if(response.data == 1) {
            this.$router.push({ path: '/login' })
          } 
        });
      },
    }
  }
  </script>
  
  <style lang="scss" scoped>
  
  </style>
  