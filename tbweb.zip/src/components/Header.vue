<template>
  <header id="dashboard-header">
    <div class="container medium">
      <div class="row">
        <div class="col-xl-6 col-6 align-self-center">
          <div class="hamburger-menu-wrapper">
            <div class="hamburger-menu" @click="openSidebar">
              <i class="fa-solid fa-bars"></i>
            </div>
            <RouterLink to="/" class="logo">
              <img v-if="isCopyLeaders()" src="../assets/images/copyleaders.png">
              <img v-else src="../assets/images/logo.png" alt="Logo">
            </RouterLink>
          </div>
        </div>
        <div class="col-xl-6 col-6 align-self-center">
          <ul class="dashboard-info">
            <li>
              <input type="checkbox" id="checkbox" @change="$emit('toggle')" :checked="false">
              <label for="checkbox" class="them-switcher-btn">
                <img src="../assets/images/icons/light-theme-icon.svg" class="light-theme-icon" alt="icon">
                <i class="fa-regular fa-moon dark-theme-icon"></i>
              </label>
            </li>
            <li>
              <div class="author-info" @click="authorInfoPopup()">
                <div class="img-wrapper">
                  <img src="../assets/images/user.png" alt="Doctor">
                </div>
                <div class="content-wrapper">
                  <p class="white">{{ username }} &nbsp;<i class="fa-solid fa-angle-down"></i></p>
                  <span>{{ plan }}</span>
                </div>
              </div>
              <ul class="dropdown-menu-popup author-info-menu" :class="{'active' : isAuthorInfoPopup}">
                <!--<li><a href="#"><i class="fa-solid fa-user"></i> Profile</a></li>
                <li><a href="#"><i class="fa fa-key" aria-hidden="true"></i> Password</a></li>-->
                <li><a @click="logout()" href="#"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
import axios from 'axios'

export default {
  name: 'DashboardHeader',
  props: {
    msg: String
  },
  data() {
    return {
      isAuthorInfoPopup: false,
      isNotificationPopup: false,
      username: '',
      plan: '',
    }
  },
  beforeMount() {
    this.getUsernameAndPlan()
  },
  methods: {
    authorInfoPopup(){
      this.isAuthorInfoPopup = !this.isAuthorInfoPopup;
      this.isNotificationPopup = false;
    },
    openSidebar(){
      this.$emit("toggleSidebar") // 👈 emit event
    },
    getUsernameAndPlan() {
      var token =  localStorage.getItem("session"); 

      axios.post(this.$api+'/getUsername',
          { 
            token: token,
          },
        )
        .then((response) => {
          this.username = response.data['username']
          this.plan = response.data['membership']
        });
    },
    isCopyLeaders() {
      if(window.location.hostname == 'web.copyleaders.co') {
        document.title = 'CopyLeaders';
        return true
      }
      else
        return false
    },
    logout() {
      localStorage.removeItem("session");
      this.$router.push('/login');
    }
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import "./src/assets/scss/standard.scss";

</style>
