<template>
  <div class="left-sidebar">
    <div id="left-sidebar">
      <div class="left-sidebar-wrapper">
        <div class="tab-menu">
          <div class="navbar-menu">
            <ul class="menu">
              <li>
                <RouterLink to="/"><i class="fa-solid fa-house"></i>Dashboard</RouterLink>
              </li>
              <li>
                <RouterLink to="/subscribe"><i class="fa-solid fa-cart-shopping"></i>Subscribe</RouterLink>
              </li>
            </ul>
          </div>

          <p class="menu-tag">TRADING</p>
          <div class="navbar-menu">
            <ul class="menu">
              <li><RouterLink to="/leaderboard"><i class="fa-solid fa-medal"></i>Leaderboard</RouterLink></li>
              <li><RouterLink to="/settings"><i class="fa-solid fa-gear"></i>Settings</RouterLink></li>
              <li><RouterLink to="/mytrades"><i data-v-0416e4bc="" class="fas fa-search"></i>My trades</RouterLink></li>
            </ul>
          </div>

          <p class="menu-tag">ACCOUNT</p>
          <div class="navbar-menu">
            <ul class="menu">
              <li><RouterLink to="/referral"><i class="fas fa-users"></i>Referral</RouterLink></li>
              <li><RouterLink to="/help"><i class="fa-solid fa-headset"></i>&nbsp;Help</RouterLink></li>
            </ul>
          </div>

          <!--<div class="navbar-menu">
            <ul class="menu">
              <li @click="isAdminMenuOpen = !isAdminMenuOpen">
                <a href="#" class="arrow-icon" :class="{ 'active': isAdminMenuOpen }"><i class="fa-solid fa-cart-shopping"></i>Admin</a>
                <ul class="sub-menu" :class="{ 'active': isAdminMenuOpen }">
                  <li><RouterLink to="/bitcoin"><i class="fa-solid fa-arrow-right-long"></i> Analytics</RouterLink></li>
                  <li><RouterLink to="/bitcoin"><i class="fa-solid fa-arrow-right-long"></i> Users</RouterLink></li>
                  <li><RouterLink to="/light-coin"><i class="fa-solid fa-arrow-right-long"></i> Positions</RouterLink></li>
                </ul>
              </li>
            </ul>
          </div>-->

        </div>
      </div>
    </div>
    <div class="overlay" @click="CloseSidebar"></div>
  </div>
</template>

<script>
export default {
  name: 'LeftSidebar',
  props: {
    msg: String
  },
  data() {
    return {
      isAdminMenuOpen: false,
    }
  },
  methods: {
    CloseSidebar(){
      this.$emit("closeSidebar") // 👈 emit event
    },
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import "./src/assets/scss/standard.scss";


</style>
