import boto3
import datetime
from dateutil.tz import tzlocal
import csv
from email import encoders
from email.mime.base import MIMEBase
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

ec2 = boto3.client('ec2')

client = boto3.client('cloudtrail')

s3client = boto3.client('s3')
ses_client = boto3.client("ses")


s3_bucket_name = 'cf-templates-169si23liwc14-us-east-1'
sender_email = "dipendra@genesesolution.com"
receiver_email_list = ["dipendra@genesesolution.com"]

def lambda_handler(event, context):
    
    volumes_to_delete = list()
    volume_detail = ec2.describe_volumes()
    
    # process each volume in volume_detail
    if volume_detail['ResponseMetadata']['HTTPStatusCode'] == 200:
        for each_volume in volume_detail['Volumes']:
            if len(each_volume['Attachments']) == 0 and each_volume['State'] == 'available':
                response = client.lookup_events(
                    LookupAttributes=[
                        {
                            'AttributeKey': 'ResourceName',
                            'AttributeValue': 'vol-05449f729351f0e9c'
                        },
                    ]
                )
                if(len(response['Events']) ==0):
                    volumes_to_delete.append(each_volume['VolumeId'])
                else:
                    for vol in response['Events']:
                        if vol['EventName'] =='DetachVolume':
                            # print(type(vol['EventTime']))
                            vol_time = vol['EventTime'].timestamp()
                            current_time = datetime.datetime.now().timestamp()
                            time_diff = current_time-vol_time
                            if time_diff > 2592000:
                                volumes_to_delete.append(each_volume['VolumeId'])
                            break
   
    print(volumes_to_delete)
    row_detials = ['S/N', "VolumeId"]
    if(len(volumes_to_delete) == 0):
        print('nothing to write')
    else:
        i=1
        s3_data = []
        for vol in volumes_to_delete:
            s3_data.append([i,vol])
            i = i+1
        with open('/tmp/abc.csv', 'w') as f: 
            write = csv.writer(f) 
            write.writerow(row_detials) 
            write.writerows(s3_data)
        
        msg = MIMEMultipart()
        msg["Subject"] = "AWS Automation Alert"
        msg["From"] = sender_email
    
        # Set message body
        body = MIMEText("Please find the attached CSV document that contains the lists of volumes to be deleted.", "plain")
        msg.attach(body)
    
        filename = "/tmp/abc.csv"  # In same directory as script
    
        with open(filename, "rb") as attachment:
            part = MIMEApplication(attachment.read())
            part.add_header("Content-Disposition",
                            "attachment",
                            filename="VolumeList.csv")
        msg.attach(part)
        response = ses_client.send_raw_email(
            Source=sender_email,
            Destinations=receiver_email_list,
            RawMessage={"Data": msg.as_string()}
        )
        s3client.upload_file('/tmp/abc.csv', s3_bucket_name , datetime.datetime.now().strftime("%Y_%m_%d-%I_%M_%S_%p")+'.csv')

    
    # for volume in volumes_to_delete:
    #     try:
    #         response = ec2.delete_volume(
    #             VolumeId=volume
    #         )
    #     except Exception as e: 
    #         print(e)