<template>
    <header>
        <nav class="navbar navbar-dark navbar-expand-md py-3">
            <div class="container"><router-link to="/" ><img v-if="!isCopyLeaders()" src="@/assets/img/logo.png"><img v-else src="@/assets/img/copyleaderslogo.png" ></router-link>
                <button @click='toggle = !toggle' data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-3">
                    <span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span>
                </button>
                <div v-if="toggle" class="collapse navbar-collapse" id="navcol-3">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item"><router-link class="nav-link" to="/">Home</router-link></li>
                        <li class="nav-item"><router-link class="nav-link" to="/leaderboard">Leaderboard</router-link></li>
                        <li class="nav-item"><router-link class="nav-link" to="/pricing">Pricing</router-link></li>
                        <li class="nav-item"><router-link class="nav-link" to="/api">API</router-link></li>
                        <!--<li class="nav-item"><a class="nav-link" href="#">Affiliate</a></li>-->
                        <li class="nav-item"><router-link class="nav-link" to="/news">News</router-link></li>
                        <li class="nav-item"><a class="nav-link" href="javascript:void(Tawk_API.toggle())">Contact us</a></li>
                    </ul>
                    <a :href="`https://web.${sitelink}/login`"><button class="btn btn-primary" type="button">Log-in</button></a> 
                    <a :href="`https://web.${sitelink}/signup`"><button class="btn btn-secondary" type="button">Sign up</button></a>
                </div>
            </div>
        </nav>
    </header>
</template>

<script>
export default {
    data() {
        return {
            sitename: '',
            sitelink: '',
            toggle: false,
        }
    },
    methods: {
        isCopyLeaders() {
            var url = window.location.hostname;

            if(url == 'copyleaders.co') {
                this.sitename = 'CopyLeaders'
                this.sitelink = 'copyleaders.co'
                return true;
            }
            else {
                this.sitename = 'Traderboard'
                this.sitelink = 'traderboard.app'
                return false;
            }
        },

    },
    mounted () {
        if(this.isCopyLeaders()) {
            document.title = 'CopyLeaders'
        }
        if(window.innerWidth > 601) {
            this.toggle = true
        }
    }
}
</script>