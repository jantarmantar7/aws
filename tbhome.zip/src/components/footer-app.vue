<template>
    <footer>
        <div class="container py-4 py-lg-5">
            <div class="row justify-content-center">
                <div class="col-sm-4 col-md-3 text-center text-lg-start d-flex flex-column">
                    <h3 class="text-white">Navigation</h3>
                    <ul class="list-unstyled">
                        <li><a :href="`https://web.${sitelink}/login`">Login</a></li>
                        <li><a :href="`https://web.${sitelink}/signup`">Sign up</a></li>
                        <li><router-link to="/leaderboard">Leaderboard</router-link></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-3 text-center text-lg-start d-flex flex-column">
                    <h3 class="text-white">Services</h3>
                    <ul class="list-unstyled">
                        <li><router-link to="/api">API</router-link></li>
                        <!-- <li><a href="#">Affiliate</a></li> -->
                        <li><router-link to="/pricing">Pricing</router-link></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-3 text-center text-lg-start d-flex flex-column social">
                    <h3 class="text-white">Social</h3>
                    <p><a target="_blank" href="https://twitter.com/traderboardapp"><i class="fab fa-twitter"></i></a><a target="_blank" href="#"><i class="fab fa-telegram-plane"></i></a><a target="_blank" href="https://www.instagram.com/traderboardapp/"><i class="fab fa-instagram"></i></a></p>
                </div>
                <div class="col-lg-3 text-center text-lg-start d-flex flex-column align-items-center order-first align-items-lg-start order-lg-last">
                    <div class="fw-bold d-flex align-items-center mb-2"></div>
                    <img v-if="!isCopyLeaders()" src="@/assets/img/logo.png">
                    <img v-else src="@/assets/img/copyleaderslogo.png" >
                </div>
            </div>
        </div>
    </footer>
</template>

<script>
export default {
    data() {
        return {
            sitename: '',
            sitelink: '',
        }
    },
    methods: {
        isCopyLeaders() {
            var url = window.location.hostname;

            if(url == 'copyleaders.co') {
                this.sitename = 'CopyLeaders'
                this.sitelink = 'copyleaders.co'
                return true;
            }
            else {
                this.sitename = 'Traderboard'
                this.sitelink = 'traderboard.app'
                return false;
            }
        }
    },
    mounted () {
        if(this.isCopyLeaders()) {
            document.title = 'CopyLeaders'
        }
    }
}
</script>