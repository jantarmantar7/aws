<template>
    <NavBar/>
    <section class="hero-primary">
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <h1 class="text-white colorful"><strong>BINANCE LEADERBOARD</strong><span><br>COPY TRADING</span></h1>
                    <p>Improve your trading experience by copying the millionaires of binance and create a passive income.</p><a :href="`https://web.${sitelink}/signup`"><button class="btn btn-secondary getstarted" type="button">Get Started</button></a>
                    <div class="partners"><img class="binance" src="@/assets/img/binance.png"><img class="bybit" src="@/assets/img/bybit.png"></div>
                </div>
                <div class="col-md-6 hero-img"><img class="img-fluid hero-img" src="@/assets/img/panel-white.png"></div>
            </div>
        </div>
    </section>
    <section class="features spaced bordersec">
        <div class="container">
            <div class="content">
                <h2 class="text-white">FEATURES</h2>
                <p>Automated copy trading on binance's richest and most profitable traders.</p>
                <div class="row boxes">
                    <div class="col">
                        <div class="row">
                            <div class="col">
                                <div class="box"><img src="@/assets/img/analytics.svg"></div>
                                <p>Public Traders<br>Analytics</p>
                            </div>
                            <div class="col">
                                <div class="box"><img src="@/assets/img/medal.svg"></div>
                                <p>Copy the best<br>&nbsp;of Binance</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="row">
                            <div class="col">
                                <div class="box"><img src="@/assets/img/lock.png"></div>
                                <p>Secure API<br>automation</p>
                            </div>
                            <div class="col">
                                <div class="box"><img src="@/assets/img/dca.png"></div>
                                <p>Auto DCA<br>and Resizing</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row boxes">
                    <div class="col">
                        <div class="row">
                            <div class="col">
                                <div class="box"><img src="@/assets/img/leverage.png"></div>
                                <p>Matching or<br>fixed leverage</p>
                            </div>
                            <div class="col">
                                <div class="box"><img src="@/assets/img/asktoadd.png"></div>
                                <p>Ask to add<br>your favourite<br>traders</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="row">
                            <div class="col">
                                <div class="box"><img src="@/assets/img/notification.png"></div>
                                <p>Email<br>notification</p>
                            </div>
                            <div class="col">
                                <div class="box"><img src="@/assets/img/ratio.png"></div>
                                <p>Fixed or<br>ratio amount</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="features spaced">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="window"><img class="dots" src="@/assets/img/dots.png">
                        <div class="line"></div>
                        <div class="content">
                            <h2 class="text-white text-center">How it works</h2>
                            <p>Setting up {{ sitename }} with your Binance or Bybit account only takes a few minutes.</p>
                            <div class="row">
                                <div class="col"><label class="form-label" for="apikey">API Key</label><input type="text" id="apikey" readonly="" value="DKgnDSJW23896ADkfmfs" name="apikey"></div>
                                <div class="col"><label class="form-label">Secret</label><input type="url" value="****************************" readonly=""></div>
                            </div>
                            <div class="row second-form-row">
                                <div class="col"><label class="form-label full" for="apikey">Fixed amount</label>
                                    <div>
                                        <div class="beforeInput">
                                            <p>USDT</p>
                                        </div><input type="text" id="apikey-3" class="full" readonly="" value="100" name="apikey">
                                    </div>
                                    <p class="or"><span>or</span></p>
                                    <div><label class="form-label full" for="apikey">Percentage of trader's original size</label>
                                        <div class="beforeInput">
                                            <p>%</p>
                                        </div><input type="text" id="apikey-2" class="full" readonly="" value="40%" name="apikey">
                                    </div>
                                </div>
                            </div><a :href="`https://web.${sitelink}/signup`"><button class="btn btn-secondary getstarted" type="button">Get Started</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="whyus spaced bordersec">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="text-center colorful">WHY <br>CHOOSE US</h2>
                </div>
                <div class="col-md-6">
                    <p>With trading the rich get richer and the poor go into<br>liquidation, but why? Most of the time, people with non-million-dollar<br>portfolios have no strategy and no risk<br>management.<br>We make you win by copying the strategies of the richest<br>and most profitable traders on Binance.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="pricing spaced" id="pricing">
        <div class="text-center content">
            <h2 class="text-center text-white">PRICING</h2>
            <p>Simple yet affordable pricing plans for beginners and experts.</p>
        </div>
        <div class="container">
            <div class="row boxes">
                <div class="col-md-6">
                    <div class="box">
                        <h4 class="text-center">Autopilot</h4>
                        <h2 class="text-center colorful">{{ AP_price }}&nbsp;</h2>
                        <div class="text-center">
                            <select @change="AP_onChange($event)">
                                <option value="4" selected>1 Month</option>
                                <option value="5">6 Months</option>
                                <option value="6">12 Months</option>
                            </select></div>
                        <p class="text-center description">We select the best traders and copy them into your account, up to 5x leverage.</p>
                        <ul class="list-unstyled text-start">
                            <li><i class="fas fa-check-circle" style="font-size: 19px;"></i>&nbsp; Up to <span class="colorful">5x Leverage</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">Preset</span>&nbsp;of traders</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp;&nbsp;<span class="colorful">Leaderboard</span>&nbsp;Copytrade</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">Auto DCA</span>&nbsp;&amp; Resizing</li>
                        </ul>
                        <div class="text-center button"><a v-bind:href="BuyAP"><button class="btn btn-secondary getstarted" type="button"><i class="fa-solid fa-bitcoin-sign"></i> Pay with Crypto</button></a></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="box">
                        <h4 class="text-center">Premium</h4>
                        <h2 class="text-center colorful">{{ PP_price }}</h2>
                        <div class="text-center">
                            <select @change="PP_onChange($event)">
                                <option value="1" selected="">1 Month</option>
                                <option value="2">6 Months</option>
                                <option value="3">12 Months</option>
                            </select></div>
                        <p class="text-center description">Allow you to customize everything and choose who to copy, up to 20x leverage.</p>
                        <ul class="list-unstyled text-start">
                            <li><i class="fas fa-check-circle" style="font-size: 19px;"></i>&nbsp; Up to <span class="colorful">20x Leverage</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; Choose who&nbsp;<span class="colorful">to copy</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp;&nbsp;<span class="colorful">Leaderboard</span>&nbsp;Copytrade</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">Auto DCA</span>&nbsp;&amp; Resizing</li>
                        </ul>
                        <div class="text-center button">
                            <a v-bind:href="BuyPPStripe"><button class="btn btn-secondary getstarted" type="button"><i class="fa-solid fa-credit-card"></i> Pay with Card</button></a>
                            <a v-bind:href="BuyPP"><button class="btn btn-secondary getstarted" type="button"><i class="fa-solid fa-bitcoin-sign"></i> Pay with Crypto</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="performance spaced bordersec">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div><img src="@/assets/img/pnl.png"></div>
                </div>
                <div class="col-md-6">
                    <h2 class="colorful">Public Performance<br>Analytics</h2>
                    <p>Choose which trader to follow based on past and current performance with the Premium plan.<br>Not sure about who to copy? Our Autopilot plan will automatically select the best performing traders through our index and copy their positions into your account.</p>
                </div>
            </div>
            <div class="row secondrow">
                <div class="col-md-6">
                    <h2 class="colorful">Become a <br>profitable trader</h2>
                    <p>No more liquidation calls, never worry again about your strategy, because you don't need one anymore!<br>Copy bulletproof strategies used by leaderboard traders and proven track record in the crypto markets.</p>
                </div>
                <div class="col-md-6">
                    <div class="text-center"><img src="@/assets/img/positions.png"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="faq spaced bordersec">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="transparent-box">
                        <h2 class="text-center colorful">FAQ</h2>
                        <p class="text-center">Let us help you setting everything up</p>
                    </div>
                    <div class="box secondary">
                        <h4>How do I get started?</h4>
                        <p>Getting started with Traderboard is very easy, you just need to sign up and subscribe to our platform.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="box">
                        <h4>How to connect Binance?</h4>
                        <p>Simply create and add your binance account API in our platform settings through settings.&nbsp;<a :href="`https://${sitelink}/news/How-to-generate-API-key-and-connect-Binance`" target="_blank">Need help?</a></p>
                    </div>
                    <div class="box secondary">
                        <h4>How to connect Bybit?</h4>
                        <p>The procedure is always the same, just create an API key and enter it in your Traderboard account.&nbsp;<a :href="`https://${sitelink}/news/How-to-generate-API-key-and-connect-Bybit`" target="_blank">Need help?</a></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <Footer/>
</template>


<script setup>
import NavBar from '@/components/Nav-bar.vue'
import Footer from '@/components/footer-app.vue'
</script>

<script>
export default {
    data() {
        return {
            AP_price: '$69',
            PP_price: '$99',
            sitename: '',
            sitelink: '',
            ref: '',
            BuyAP: 'https://web.traderboard.app/signup?id=4&type=Autopilot',
            BuyPP: 'https://web.traderboard.app/signup?id=1&type=Premium',
        }
    },
    methods: {
        AP_onChange:function(event){
            var value = event.target.value;
            if(value == 4) {
                this.BuyAP = 'https://web.'+this.sitelink+'/signup?id=4&type=Autopilot&method=crypto';
                this.AP_price = '$69';
            }
            else if(value == 5) {
                this.BuyAP = 'https://web.'+this.sitelink+'/signup?id=5&type=Autopilot&method=crypto';
                this.AP_price = '$333';
            }
            else if(value == 6) {
                this.BuyAP = 'https://web.'+this.sitelink+'/signup?id=6&type=Autopilot&method=crypto';
                this.AP_price = '$666';
            }
        },
        PP_onChange:function(event){
            var value = event.target.value;
            if(value == 1) {
                this.BuyPP = 'https://web.'+this.sitelink+'/signup?id=1&type=Premium&method=crypto';
                this.BuyPPStripe = 'https://web.'+this.sitelink+'/signup?id=1&type=Premium&method=stripe';
                this.PP_price = '$99';
            }
            else if(value == 2) {
                this.BuyPP = 'https://web.'+this.sitelink+'/signup?id=2&type=Premium&method=crypto';
                this.BuyPPStripe = 'https://web.'+this.sitelink+'/signup?id=2&type=Premium&method=stripe';
                this.PP_price = '$444';
            }
            else if(value == 3) {
                this.BuyPP = 'https://web.'+this.sitelink+'/signup?id=3&type=Premium&method=crypto';
                this.BuyPPStripe = 'https://web.'+this.sitelink+'/signup?id=3&type=Premium&method=stripe';
                this.PP_price = '$888';
            }
        },
        isCopyLeaders() {
            var url = window.location.hostname;

            if(url == 'copyleaders.co') {
                this.sitename = 'CopyLeaders'
                this.sitelink = 'copyleaders.co'
                this.BuyAP = 'https://web.copyleaders.co/signup?id=4&type=Autopilot&method=crypto'
                this.BuyPP = 'https://web.copyleaders.co/signup?id=1&type=Premium&method=crypto'
                this.BuyPPStripe = 'https://web.copyleaders.co/signup?id=1&type=Premium&method=stripe'
                return true;
            }
            else {
                this.sitename = 'Traderboard'
                this.sitelink = 'traderboard.app'
                this.BuyAP = 'https://web.traderboard.app/signup?id=4&type=Autopilot&method=crypto'
                this.BuyPP = 'https://web.traderboard.app/signup?id=1&type=Premium&method=crypto'
                this.BuyPPStripe = 'https://web.traderboard.app/signup?id=1&type=Premium&method=stripe'
                return false;
            }
        }
    },
    mounted () {
        if(this.isCopyLeaders()) {
            document.title = 'CopyLeaders'
        }
        if(this.$route.query.ref) {
            this.ref = '&ref='+this.$route.query.ref
            this.BuyAP = this.BuyAP+''+this.ref
            this.BuyPP = this.BuyPP+''+this.ref
            this.BuyPPStripe = this.BuyPPStripe+''+this.ref
        }
    }
}
</script>

<style>
@import url('@/assets/css/bootstrap.min.css');
@import url('@/assets/css/style.css');
@import url('@/assets/fonts/fontawesome-all.min.css');
</style>