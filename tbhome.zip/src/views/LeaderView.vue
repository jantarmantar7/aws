<template>
    <NavBar/>
    <section class="hero-primary">
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <h1 class="text-white colorful"><strong>BEST PERFORMING</strong><span><br>ON LEADEDERBOARD</span></h1>
                    <p>Spy the positions and performance of the best traders of Binance.</p><a :href="`https://web.${sitelink}/signup`"><button class="btn btn-secondary getstarted" type="button">Get Started</button></a>
                </div>
                <div class="col-md-6 hero-img leader"><img class="img-fluid hero-img" src="@/assets/img/leaderboard.png"></div>
            </div>
        </div>
    </section>
    <section class="leaderslist bordersec">
        <div class="container">
            <div class="row" v-html="leaders">
                
            </div>
        </div>
    </section>
    <Footer/>
</template>

<script setup>
import NavBar from '@/components/Nav-bar.vue'
import Footer from '@/components/footer-app.vue'
import axios from 'axios';
</script>

<script>
export default {
  data() {
    return {
      leaders: '',
      sitename: '',
      sitelink: '',
    }
  },
  methods: {
    load() {
      axios.get('https://api.traderboard.app/newListTraders.php')
      .then((response) => {
        this.leaders = response.data;
      });
    },
    isCopyLeaders() {
        var url = window.location.hostname;

        if(url == 'copyleaders.co') {
            this.sitename = 'CopyLeaders'
            this.sitelink = 'copyleaders.co'
            this.BuyAP = 'https://web.copyleaders.co/signup?id=4&type=Autopilot'
            this.BuyPP = 'https://web.copyleaders.co/signup?id=1&type=Premium'
            return true;
        }
        else {
            this.sitename = 'Traderboard'
            this.sitelink = 'traderboard.app'
            this.BuyAP = 'https://web.traderboard.app/signup?id=4&type=Autopilot'
            this.BuyPP = 'https://web.traderboard.app/signup?id=1&type=Premium'
            return false;
        }
    }
  },
  mounted() {
    this.load();
    if(this.isCopyLeaders()) {
      document.title = 'CopyLeaders'
    }
  }
}
</script>

<style>
@import url('@/assets/css/bootstrap.min.css');
@import url('@/assets/css/style.css');
@import url('@/assets/fonts/fontawesome-all.min.css');
</style>