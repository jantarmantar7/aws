<template>
    <NavBar/>
    <section class="hero-primary">
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <h1 class="text-white colorful">{{ title }}</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="spaced bordersec">
        <div class="container">
            <div v-html="content"></div>
        </div>
    </section>
    <Footer/>
</template>

<script setup>
import NavBar from '@/components/Nav-bar.vue'
import Footer from '@/components/footer-app.vue'
import axios from 'axios';
</script>

<script>
export default {
    data() {
        return {
            title: '',
            content: ''
        }
    },
    methods: {
        load() {
            axios.get('https://traderboard.app/php/viewArticle.php?title='+this.$route.params.slug)
            .then((response) => {
                this.content = response.data.content;
                this.title = response.data.title;
                this.title = this.title.replaceAll('-', ' ');
            });
        },
    },
    mounted() {
        this.load()
    }
}
</script>

<style>
@import url('@/assets/css/bootstrap.min.css');
@import url('@/assets/css/style.css');
@import url('@/assets/fonts/fontawesome-all.min.css');
</style>