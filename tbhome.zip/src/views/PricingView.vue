<template>
    <NavBar/>
    <section class="hero-primary">
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <h1 class="text-white colorful"><strong>PRICING</strong></h1>
                    <p>Simple yet affordable pricing to start copy-trading the millionaires of binance.</p>
                </div>
                <div class="col-md-6 hero-img leader"><img class="img-fluid hero-img" src="@/assets/img/rocket.png"></div>
            </div>
        </div>
    </section>
    <section class="pricing spaced bordersec" id="pricing">
        <div class="text-center content">
            <h2 class="text-center text-white">PLANS</h2>
            <p>Simple yet affordable pricing plans for beginners and experts.</p>
        </div>
        <div class="container">
            <div class="row boxes">
                <div class="col-md-6">
                    <div class="box">
                        <h4 class="text-center">Autopilot</h4>
                        <h2 class="text-center colorful">{{ AP_price }}&nbsp;</h2>
                        <div class="text-center">
                            <select @change="AP_onChange($event)">
                                <option value="4" selected>1 Month</option>
                                <option value="5">6 Months</option>
                                <option value="6">12 Months</option>
                            </select></div>
                        <p class="text-center description">We select the best traders and copy them into your account, up to 5x leverage.</p>
                        <ul class="list-unstyled text-start">
                            <li><i class="fas fa-check-circle" style="font-size: 19px;"></i>&nbsp; Up to <span class="colorful">5x Leverage</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">Preset</span>&nbsp;of traders</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp;&nbsp;<span class="colorful">Leaderboard</span>&nbsp;Copytrade</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">Auto DCA</span>&nbsp;&amp; Resizing</li>
                        </ul>
                        <div class="text-center button"><a v-bind:href="BuyAP"><button class="btn btn-secondary getstarted" type="button"><i class="fa-solid fa-bitcoin-sign"></i> Pay with Crypto</button></a></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="box">
                        <h4 class="text-center">Premium</h4>
                        <h2 class="text-center colorful">{{ PP_price }}</h2>
                        <div class="text-center">
                            <select @change="PP_onChange($event)">
                                <option value="1" selected="">1 Month</option>
                                <option value="2">6 Months</option>
                                <option value="3">12 Months</option>
                            </select></div>
                        <p class="text-center description">Allow you to customize everything and choose who to copy, up to 20x leverage.</p>
                        <ul class="list-unstyled text-start">
                            <li><i class="fas fa-check-circle" style="font-size: 19px;"></i>&nbsp; Up to <span class="colorful">20x Leverage</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; Choose who&nbsp;<span class="colorful">to copy</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp;&nbsp;<span class="colorful">Leaderboard</span>&nbsp;Copytrade</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">Auto DCA</span>&nbsp;&amp; Resizing</li>
                        </ul>
                        <div class="text-center button">
                            <a v-bind:href="BuyPPStripe"><button class="btn btn-secondary getstarted" type="button"><i class="fa-solid fa-credit-card"></i> Pay with Card</button></a>
                            <a v-bind:href="BuyPP"><button class="btn btn-secondary getstarted" type="button"><i class="fa-solid fa-bitcoin-sign"></i> Pay with Crypto</button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="faq spaced bordersec">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="transparent-box">
                        <h2 class="text-center colorful">FAQ</h2>
                        <p class="text-center">Let us help you setting everything up</p>
                    </div>
                    <div class="box secondary">
                        <h4>How do I get started?</h4>
                        <p>Getting started with Traderboard is very easy, you just need to sign up and subscribe to our platform.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="box">
                        <h4>How to connect Binance?</h4>
                        <p>Simply create and add your binance account API in our platform settings through settings.&nbsp;<a href="https://traderboard.app/blog/How-to-generate-API-key-and-connect-Binance" target="_blank">Need help?</a></p>
                    </div>
                    <div class="box secondary">
                        <h4>How to connect Bybit?</h4>
                        <p>The procedure is always the same, just create an API key and enter it in your Traderboard account.&nbsp;<a href="https://traderboard.app/blog/How-to-generate-API-key-and-connect-Bybit" target="_blank">Need help?</a></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <Footer/>
</template>

<script setup>
import NavBar from '@/components/Nav-bar.vue'
import Footer from '@/components/footer-app.vue'
</script>

<script>
export default {
    data() {
        return {
            AP_price: '$69',
            PP_price: '$99',
            sitename: '',
            sitelink: '',
            BuyAP: 'https://web.traderboard.app/signup?id=4&type=Autopilot&method=crypto',

            BuyPP: 'https://web.traderboard.app/signup?id=1&type=Premium&method=crypto',
            BuyPPStripe: 'https://web.traderboard.app/signup?id=1&type=Premium&method=stripe',
        }
    },
    methods: {
        AP_onChange:function(event){
            var value = event.target.value;
            if(value == 4) {
                this.BuyAP = 'https://web.'+this.sitelink+'/signup?id=4&type=Autopilot&method=crypto';
                this.AP_price = '$69';
            }
            else if(value == 5) {
                this.BuyAP = 'https://web.'+this.sitelink+'/signup?id=5&type=Autopilot&method=crypto';
                this.AP_price = '$333';
            }
            else if(value == 6) {
                this.BuyAP = 'https://web.'+this.sitelink+'/signup?id=6&type=Autopilot&method=crypto';
                this.AP_price = '$666';
            }
        },
        PP_onChange:function(event){
            var value = event.target.value;
            if(value == 1) {
                this.BuyPP = 'https://web.'+this.sitelink+'/signup?id=1&type=Premium&method=crypto';
                this.BuyPPStripe = 'https://web.'+this.sitelink+'/signup?id=1&type=Premium&method=stripe';
                this.PP_price = '$99';
            }
            else if(value == 2) {
                this.BuyPP = 'https://web.'+this.sitelink+'/signup?id=2&type=Premium&method=crypto';
                this.BuyPPStripe = 'https://web.'+this.sitelink+'/signup?id=2&type=Premium&method=stripe';
                this.PP_price = '$444';
            }
            else if(value == 3) {
                this.BuyPP = 'https://web.'+this.sitelink+'/signup?id=3&type=Premium&method=crypto';
                this.BuyPPStripe = 'https://web.'+this.sitelink+'/signup?id=3&type=Premium&method=stripe';
                this.PP_price = '$888';
            }
        },
        isCopyLeaders() {
            var url = window.location.hostname;

            if(url == 'copyleaders.co') {
                this.sitename = 'CopyLeaders'
                this.sitelink = 'copyleaders.co'
                this.BuyAP = 'https://web.copyleaders.co/signup?id=4&type=Autopilot&method=crypto'
                this.BuyPP = 'https://web.copyleaders.co/signup?id=1&type=Premium&method=crypto'
                this.BuyPPStripe = 'https://web.copyleaders.co/signup?id=1&type=Premium&method=stripe'
                return true;
            }
            else {
                this.sitename = 'Traderboard'
                this.sitelink = 'traderboard.app'
                this.BuyAP = 'https://web.traderboard.app/signup?id=4&type=Autopilot&method=crypto'
                this.BuyPP = 'https://web.traderboard.app/signup?id=1&type=Premium&method=crypto'
                this.BuyPPStripe = 'https://web.traderboard.app/signup?id=1&type=Premium&method=stripe'
                return false;
            }
        }
    },
    mounted () {
        if(this.isCopyLeaders()) {
            document.title = 'CopyLeaders'
        }
        if(this.$route.query.ref) {
            this.ref = '&ref='+this.$route.query.ref
            this.BuyAP = this.BuyAP+''+this.ref
            this.BuyPP = this.BuyPP+''+this.ref
            this.BuyPPStripe = this.BuyPPStripe+''+this.ref
        }
    }
}
</script>

<style>
@import url('@/assets/css/bootstrap.min.css');
@import url('@/assets/css/style.css');
@import url('@/assets/fonts/fontawesome-all.min.css');
</style>