<template>
    <NavBar/>
    <section class="hero-primary">
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <h1 class="text-white colorful">LATEST <strong>NEWS</strong><span></span></h1>
                    <p>Read our latest articles to remain updated on crypto and financial markets.</p>
                </div>
                <div class="col-md-6 hero-img newspaper"><img class="img-fluid hero-img" src="@/assets/img/news.png"></div>
            </div>
        </div>
    </section>
    <section class="spaced bordersec">
        <div class="container" v-html="articles">
            
        </div>
    </section>
    <Footer/>
</template>


<script setup>
import NavBar from '@/components/Nav-bar.vue'
import Footer from '@/components/footer-app.vue'
import axios from 'axios';
</script>

<script>
export default {
  data() {
    return {
      articles: '',
    }
  },
  methods: {
    load() {
      axios.get('https://traderboard.app/php/articlesList.php')
      .then((response) => {
        this.articles = response.data
      });
    },
  },
  mounted() {
    this.load();
  }
}
</script>

<style>
@import url('@/assets/css/bootstrap.min.css');
@import url('@/assets/css/style.css');
@import url('@/assets/fonts/fontawesome-all.min.css');
</style>