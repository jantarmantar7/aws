<template>
    <NavBar/>
    <section class="hero-primary">
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <h1 class="text-white colorful"><strong>API for Developers</strong></h1>
                    <p>Whether it's a personal project or a service integration to your business, we have a plan for you.</p>
                </div>
                <div class="col-md-6 hero-img"><img class="img-fluid hero-img" src="@/assets/img/laptop.png"></div>
            </div>
        </div>
    </section>
    <section class="pricing api spaced bordersec" id="pricing">
        <div class="text-center content">
            <h2 class="text-center text-white">PLANS</h2>
            <p>Designed to be easy to use and provide an high flexibility for your project.</p>
        </div>
        <div class="container">
            <div class="row boxes">
                <div class="col-md-6">
                    <div class="box">
                        <h4 class="text-center">Standard</h4>
                        <h2 class="text-center colorful">$89/mo</h2>
                        <p class="text-center description">Affordable endpoint to suit personal projects and small companies.</p>
                        <ul class="list-unstyled text-start">
                            <li><i class="fas fa-check-circle"></i>&nbsp; Add up to <span class="colorful">5 traders</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; Updating every <span class="colorful">30 seconds</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp;&nbsp;<span class="colorful">Unlimited</span>&nbsp;requests</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">JSON</span> output</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; Easy to <span class="colorful">integrate</span></li>
                        </ul>
                        <div class="text-center button"><a @click="showEmail" href="mailto:traderboard@proton.me"><button class="btn btn-secondary getstarted" type="button">Contact us</button></a></div>
                        <div class="text-center" v-if="email" v-html="email"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="box">
                        <h4 class="text-center">Corporate</h4>
                        <h2 class="text-center colorful">$199/mo</h2>
                        <p class="text-center description">Built for large companies who need ultra-high refresh rate and flexibility.</p>
                        <ul class="list-unstyled text-start">
                            <li><i class="fas fa-check-circle"></i>&nbsp; Add up to <span class="colorful">50 traders</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; Updating every <span class="colorful">10 seconds</span></li>
                            <li><i class="fas fa-check-circle"></i>&nbsp;&nbsp;<span class="colorful">Unlimited</span>&nbsp;requests</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; <span class="colorful">JSON</span> output</li>
                            <li><i class="fas fa-check-circle"></i>&nbsp; Easy to <span class="colorful">integrate</span></li>
                        </ul>
                        <div class="text-center button"><a @click="showEmail" href="mailto:traderboard@proton.me"><button class="btn btn-secondary getstarted" type="button">Contact us</button></a></div>
                        <div class="text-center" v-if="email" v-html="email"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="faq spaced bordersec">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="transparent-box">
                        <h2 class="text-center colorful">FAQ</h2>
                        <p class="text-center">Everything you need to know about our API</p>
                    </div>
                    <div class="box secondary">
                        <h4>How can I integrate the API?</h4>
                        <p>It provides a JSON formatted output which can easily be read and transformed into array by any programming language.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="box">
                        <h4>Do I need a server?</h4>
                        <p>We deploy the API on our servers and simply provide you a link to call in your code.</p>
                    </div>
                    <div class="box secondary">
                        <h4>How can I add custom traders?</h4>
                        <p>You can ask our team to add custom traders from leaderboard, we will make sure to provide you quick support.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <Footer/>
</template>

<script setup>
import NavBar from '@/components/Nav-bar.vue'
import Footer from '@/components/footer-app.vue'
</script>

<script>
export default {
    data() {
        return {
            email: false
        }
    },
    methods: {
        showEmail() {
            this.email = '<p>traderboard@proton.me</p>';
        }
    }
}
</script>

<style>
@import url('@/assets/css/bootstrap.min.css');
@import url('@/assets/css/style.css');
@import url('@/assets/fonts/fontawesome-all.min.css');
</style>